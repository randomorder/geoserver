CITE Data
=========

The Open Geospatial Consortium Compliance and Intolerability Testing Initiative (CITE)
only tests the WCS protocol and does not provide any test data.

For more information:

* http://cite.opengeospatial.org/teamengine/
* http://cite.opengeospatial.org/teamengine/wcs-1.0.0/docs/wcs/1.0.0/index.html